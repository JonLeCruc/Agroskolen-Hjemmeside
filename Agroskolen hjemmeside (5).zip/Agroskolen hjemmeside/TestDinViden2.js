/*Her opretter vi et todimentionelt array. Et array starter altid på index 0.
  For at tilgå købehavn skal vi bruge correctAnswers[0], så har vi fat i array'et med København */
 // Forskellen på et 1dim vs 2dim array er blot at vi nester et array inde i et array
 var correctAnswers = [
    ["18-23 grise"],
    ["Typisk 4 uger"],
    ["Byg", "Hvede", "Havre"],
    ["En kastreret hangris"],
    [""],
    ["For at se om der er grise i soen"],
    ["Landrace, Yorkshire og Duroc"],
    ["120 kg"],
    ["De bliver bedøvet før aflivning"],
    ["At de har det godt og vokser"],
 
]

// Holder på brugerens svar
var userAnswers = [];

var storedUserAnswers = [[]];

// Holder på scoren
var score = 0;

// Metode bliver kørt hver gang brugeren klikker på en checkbox
// Den har en parameter som er blevet angivet i html filen (index er det svar man har vaglt)
function InputCheckEvent(answer) {
  // Her tjekker vi på om array'et allerede indeholder den valgte svarmulighed
  if (userAnswers.includes(answer)) {
    // Her laver jeg et forloop til at finde det index den valgte svarmulighed ligger på så vi kan fjerne det
    for (let index = 0; index < userAnswers.length; index++) {
      if (userAnswers[index] == answer) {
        // .splice tillader 2 argumenter. 1 indexet på den jeg vil fjerne. 2 antal elementer jeg vil fjerne
        userAnswers.splice(index, 1);
        return;
      }
    }
    return;
  }
  // Pusher ny item til mit array/tilføjer
  userAnswers.push(answer);
}

// Function bliver kaldt når der klikkes på tjeksvar knappen
function SubmitButton(index) {
  ChangeQuestion(index);

  if (index == 2) {
    if(lilleSnyder(correctAnswers[index], userAnswers)) {
      userAnswers = correctAnswers[index];
    }
  }
  if (index == 0) {
    storedUserAnswers = [userAnswers];
  } else {
    storedUserAnswers.push(userAnswers);
  }
  // Tjekker om svar array matcher det korrekte svar array
  if (correctAnswers[index].toString() == userAnswers.toString()) {
    // Sætter userAnswers til et tomt array så den er klar til næste spørgsmål
    userAnswers = [];
    // Tilføjer 1 til score
    score++;
    return;
  }
  console.log("Wrong!");
  userAnswers = [];
}

function ChangeQuestion(index) {
  var questionBox = document.getElementById("question" + index);
  index++;
  var questionBoxNext = document.getElementById("question" + index);

  // Henter spørgsmål counter
  index++;
  document.getElementById("question-counter").innerHTML = index + "/10";

  questionBox.style = "display: none;";
  questionBoxNext.style = "display: block;";
}

function CompleteQuiz(index) {
  var questionBox = document.getElementById("question" + index);
  questionBox.style = "display: none;";

  if (correctAnswers[index].toString() == userAnswers.toString()) {
    score++;
  }

  var result = document.getElementById("result");
  result.style = "display: block;";
  CreateTable();
  document.getElementById("question-counter").style = "display: none";

  document.getElementById("score").innerHTML = ScoreMessage();

  document.getElementById("correct-answers").innerHTML = score + "/10";
}

function ScoreMessage() {
  if (score < 3) {
    return "Det gik ikke for godt";
  } else if (score < 5) {
    return "Det kan du gøre bedre";
  } else if (score < 7) {
    return "Det gik fint";
  } else if (score <= 11) {
    return "Flot klaret!";
  } else {
    return "Super flot!";
  }
}

function CreateTable() {
    for (let index = 0; index < correctAnswers.length; index++) {
      var newRow = document.createElement("tr");
      var correctCell = document.createElement("td");
      var userCell = document.createElement("td");
      var iconCell = document.createElement("td");

      if (index === 9) {
        iconCell.innerHTML = "✓"
      }
      else {
        correctCell.innerHTML = correctAnswers[index];
        userCell.innerHTML = storedUserAnswers[index];
        if(correctCell.innerHTML === userCell.innerHTML) {
            iconCell.innerHTML = "✓"
        }
        else {
            iconCell.innerHTML = "X"
        }
      }

      newRow.append(correctCell);
        newRow.append(userCell);         
        newRow.append(iconCell);
     document.getElementById("rows").appendChild(newRow);
    }
}

function lilleSnyder(correctArray, userArray) {
  let counter = 0;
  for (let index = 0; index < correctArray.length; index++) {
    for (let i = 0; i < userArray.length; i++) {
      if(correctArray[index] === userArray[i]) {
        counter++;
      }
    }
  }
  console.log(counter + " " + correctArray.length);
  if(counter == correctArray.length){
    return true;
  }
  return false;
}
