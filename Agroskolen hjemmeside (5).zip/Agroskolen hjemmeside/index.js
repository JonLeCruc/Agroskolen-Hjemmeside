function Knap1(){
    
    $('#modal1')
    .modal('show')
;
}

function Knap2(){
    
    $('#modal2')
    .modal('show')
;
}

function Knap3(){
    
    $('#modal3')
    .modal('show')
;
}

function Knap4(){
    
    $('#modal4')
    .modal('show')
;
}

function Knap5(){
    
    $('#modal5')
    .modal('show')
;
}

function Knap6(){
    
    $('#modal6')
    .modal('show')
;
}

function Knap7(){
    
    $('#modal7')
    .modal('show')
;
}

function Knap8(){
    
    $('#modal8')
    .modal('show')
;
}

function Knap9(){
    
    $('#modal9')
    .modal('show')
;
}